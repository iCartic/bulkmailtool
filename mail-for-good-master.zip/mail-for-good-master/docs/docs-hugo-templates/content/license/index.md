---
title: "License"
date: 2017-09-30T16:55:45-05:00
---

Copyright (c) 2017, freeCodeCamp.

This computer software is licensed under the [BSD-3-Clause](https://github.com/freeCodeCamp/Mail-for-Good/blob/master/LICENSE.md).