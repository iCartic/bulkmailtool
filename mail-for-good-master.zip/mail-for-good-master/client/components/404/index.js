import React from 'react';

const NotFound = () => {
  return (
    <div>
      <section className="content-header">
        <h1>Page not found
          <small>Please check the URL</small>
        </h1>
      </section>
    </div>
  );
};

export default NotFound;
