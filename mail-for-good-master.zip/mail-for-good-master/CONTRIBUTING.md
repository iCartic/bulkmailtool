All Open Source for Good projects follow Free Code Camp's [contributor's guide](https://github.com/FreeCodeCamp/FreeCodeCamp/blob/staging/CONTRIBUTING.md).
